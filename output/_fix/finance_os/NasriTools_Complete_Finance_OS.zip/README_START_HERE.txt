━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Complete Finance OS — NasriTools
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thank you for your purchase! 🧡

WHAT'S IN THIS BUNDLE
  • Budget_Tracker.xlsx
  • Freelancer_Invoice_Tracker.xlsx
  • Debt_Payoff_Planner.xlsx
  • Emergency_Fund_Tracker.xlsx
  • Grocery_Budget_Tracker.xlsx

HOW TO USE (2 minutes)
1. Unzip this folder
2. Go to sheets.google.com → blank spreadsheet
3. File → Import → Upload → pick a template
4. Choose "Replace spreadsheet" → done!
   (Or open directly in Excel — both work.)

Each template has a START HERE tab with instructions.

TIP: Delete the sample rows once you see how it works.

Need help? Message NasriTools on Etsy — I reply fast.
If you love the templates, a 5-star review means the world
to a small shop like mine. Thank you!

— Nasri
nasritools.etsy.com • Buy once, own forever
